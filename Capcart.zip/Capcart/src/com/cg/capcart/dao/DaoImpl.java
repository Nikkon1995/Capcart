package com.cg.capcart.dao;

import java.util.ArrayList;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.TypedQuery;
import org.springframework.stereotype.Repository;
import com.cg.capcart.model.ActionCustomer;
import com.cg.capcart.model.ActionMerchant;
import com.cg.capcart.model.AllProductsTable;
import com.cg.capcart.model.MerchantInfo;
import com.cg.capcart.model.MerchantCoupon;
import com.cg.capcart.model.MerchantDiscount;
import com.cg.capcart.model.User;
import com.cg.capcart.model.UserCart;
import com.cg.capcart.model.UserOrder;
import com.cg.capcart.model.UserWishList;

@Repository
public class DaoImpl implements IDao {

	// Getting the entity manager
	@PersistenceContext
	EntityManager manager;

	/******************* Admin methods ************************/

	// Get list of existing merchants
	@Override
	public ArrayList<ActionMerchant> getAllMerchant() {
		ArrayList<ActionMerchant> list = new ArrayList<>();
		String jpql = "Select merchant from ActionMerchant merchant";
		TypedQuery<ActionMerchant> query = manager.createQuery(jpql, ActionMerchant.class);
		list = (ArrayList<ActionMerchant>) query.getResultList();
		return list;
	}

	// Remove an existing merchant
	@Override
	public String removeMerchant(Integer id) {
		ActionMerchant merchant = manager.find(ActionMerchant.class, id);
		String jpql = "Select product from AllProductsTable product where product.merchantName = :name";
		TypedQuery<AllProductsTable> query = manager.createQuery(jpql, AllProductsTable.class);
		query.setParameter("name", merchant.getMerchantName());
		ArrayList<AllProductsTable> list = (ArrayList<AllProductsTable>) query.getResultList();
		for (AllProductsTable products : list)
			manager.remove(products);
		manager.remove(merchant);
		return "Merchant has been removed";
	}

	// Get list of all existing users
	@Override
	public ArrayList<ActionCustomer> getAllCustomer() {
		ArrayList<ActionCustomer> list = new ArrayList<>();
		String jpql = "Select customer from ActionCustomer customer";
		TypedQuery<ActionCustomer> query = manager.createQuery(jpql, ActionCustomer.class);
		list = (ArrayList<ActionCustomer>) query.getResultList();
		return list;
	}

	// Remove existing user
	@Override
	public String removeCustomer(Integer id) {
		ActionCustomer cust = manager.find(ActionCustomer.class, id);
		ArrayList<UserOrder> list = getAllOrdersById(id);
		ArrayList<UserCart> list1 = getCartDetails(id);
		ArrayList<UserWishList> list2 = getWishListDetails(id);
		if ((list != null) && (list1 != null) && (list2 != null)) {
			for (UserOrder order : list)
				manager.remove(order);
			for (UserCart cart : list1)
				manager.remove(cart);
			for (UserWishList wish : list2)
				manager.remove(wish);
		}
		manager.remove(cust);
		return "Customer has been removed";

	}

	// Get list of all existing products
	@Override
	public ArrayList<AllProductsTable> getAllProducts() {
		ArrayList<AllProductsTable> list = new ArrayList<>();
		String jpql = "SELECT product FROM AllProductsTable product";
		TypedQuery<AllProductsTable> query = manager.createQuery(jpql, AllProductsTable.class);
		list = (ArrayList<AllProductsTable>) query.getResultList();
		return list;
	}

	// remove a perticular product
	@Override
	public String removeProduct(Integer id) {
		AllProductsTable product = manager.find(AllProductsTable.class, id);
		ArrayList<MerchantCoupon> list = getAllCoupons(id);
		ArrayList<MerchantDiscount> list1 = getAllDiscounts(id);
		for (MerchantCoupon coupon : list)
			manager.remove(coupon);
		for (MerchantDiscount discount : list1)
			manager.remove(discount);
		manager.remove(product);
		return "Product has been removed";
	}

	// List of all waiting merchant Approvals
	@Override
	public ArrayList<MerchantInfo> getAllMerchantApprovals() {
		ArrayList<MerchantInfo> list = new ArrayList<>();
		String jpql = "Select merchant from MerchantInfo merchant";
		TypedQuery<MerchantInfo> query = manager.createQuery(jpql, MerchantInfo.class);
		list = (ArrayList<MerchantInfo>) query.getResultList();
		return list;
	}

	// Accepting a merchant approval
	@Override
	public void approvedMerchant(Integer id) {
		MerchantInfo merchant = manager.find(MerchantInfo.class, id);
		ActionMerchant action = new ActionMerchant();
		action.setMerchantName(merchant.getMerchantName());
		action.setEmailId(merchant.getEmailId());
		action.setContactNo(merchant.getContactNo());
		action.setCompanyName(merchant.getCompanyName());
		action.setMerchantAddress(merchant.getMerchantAddress());
		action.setMerchantUsername(merchant.getMerchantUsername());
		action.setMerchantPassword(merchant.getMerchantPassword());
		manager.persist(action);
		manager.remove(merchant);
	}

	// deleting a merchant approval
	@Override
	public void declinedMerchant(Integer id) {
		MerchantInfo merchant = manager.find(MerchantInfo.class, id);
		manager.remove(merchant);
	}

	// Get list of all customer approvals
	@Override
	public ArrayList<User> getAllUserApprovals() {
		ArrayList<User> list = new ArrayList<>();
		String jpql = "Select user from User user";
		TypedQuery<User> query = manager.createQuery(jpql, User.class);
		list = (ArrayList<User>) query.getResultList();
		return list;
	}

	// Approving a particular User Approval
	@Override
	public void approvedUser(Integer id) {
		User user = manager.find(User.class, id);
		ActionCustomer action = new ActionCustomer();
		action.setName(user.getName());
		action.setUserName(user.getUserName());
		action.setPassword(user.getPassword());
		action.setEmailId(user.getEmailId());
		action.setContactNo(user.getContactNo());
		action.setAddress(user.getAddress());
		action.setGender(user.getGender());
		manager.persist(action);
		manager.remove(user);
	}

	// Declining a particular User approval
	@Override
	public void declinedUser(Integer id) {
		User user = manager.find(User.class, id);
		manager.remove(user);

	}

	// Getting all coupons related to a product
	@Override
	public ArrayList<MerchantCoupon> getAllCoupons(Integer id) {
		ArrayList<MerchantCoupon> list = new ArrayList<>();
		String jpql = "Select coupons from MerchantCoupon coupons where coupons.productId = :id";
		TypedQuery<MerchantCoupon> query = manager.createQuery(jpql, MerchantCoupon.class);
		query.setParameter("id", id);
		list = (ArrayList<MerchantCoupon>) query.getResultList();
		return list;
	}

	// Getting all discounts related to a product
	@Override
	public ArrayList<MerchantDiscount> getAllDiscounts(Integer id) {
		ArrayList<MerchantDiscount> list = new ArrayList<>();
		String jpql = "Select discounts from MerchantDiscount discounts where discounts.productId = :id";
		TypedQuery<MerchantDiscount> query = manager.createQuery(jpql, MerchantDiscount.class);
		query.setParameter("id", id);
		list = (ArrayList<MerchantDiscount>) query.getResultList();
		return list;
	}

	/******************* Customer methods ************************/

	// Validating login of a customer
	@Override
	public ActionCustomer validateCustomer(String uname, String passward) {
		String jpql = "Select cust from ActionCustomer cust where cust.userName= :uname";
		TypedQuery<ActionCustomer> query = manager.createQuery(jpql, ActionCustomer.class);
		query.setParameter("uname", uname);
		ActionCustomer cust = query.getSingleResult();
		if (cust.getPassword() == passward)
			return cust;
		else
			return null;
	}

	// Registering a new Customer
	@Override
	public void registerNewCustomer(User user) {
		manager.persist(user);
	}

	// Method for forgot passward
	@Override
	public String forgotPassward(String uname) {
		String jpql = "Select cust from ActionCustomer cust where cust.userName= :uname";
		TypedQuery<ActionCustomer> query = manager.createQuery(jpql, ActionCustomer.class);
		query.setParameter("uname", uname);
		ActionCustomer customer = query.getSingleResult();
		String newPass = "ABC@123";
		customer.setPassword(newPass);
		return newPass;
	}

	// Method for changing the passward
	@Override
	public void changePassward(String uname, String passward) {
		String jpql = "Select cust from ActionCustomer cust where cust.userName= :uname";
		TypedQuery<ActionCustomer> query = manager.createQuery(jpql, ActionCustomer.class);
		query.setParameter("uname", uname);
		ActionCustomer customer = query.getSingleResult();
		customer.setPassword(passward);
	}

	// Getting list of all orders of a customer
	@Override
	public ArrayList<UserOrder> getAllOrdersById(Integer userId) {
		ArrayList<UserOrder> list = new ArrayList<>();
		String jpql = "Select orders from UserOrder orders where orders.id = :id";
		TypedQuery<UserOrder> query = manager.createQuery(jpql, UserOrder.class);
		query.setParameter("id", userId);
		list = (ArrayList<UserOrder>) query.getResultList();
		return list;
	}

	// Getting list of products in a perticular category
	@Override
	public ArrayList<AllProductsTable> getAllProductsByName(String category) {
		ArrayList<AllProductsTable> list = new ArrayList<>();
		String jpql = "Select products from AllProductsTable products where products.category= :category";
		TypedQuery<AllProductsTable> query = manager.createQuery(jpql, AllProductsTable.class);
		query.setParameter("category", category);
		list = (ArrayList<AllProductsTable>) query.getResultList();
		return list;
	}

	// Showing a particular product after selection
	@Override
	public AllProductsTable getProductById(Integer id) {
		return manager.find(AllProductsTable.class, id);
	}

	// Getting cart details and adding to a cart
	@Override
	public ArrayList<UserCart> getCartDetails(Integer id) {
		ArrayList<UserCart> list = new ArrayList<>();
		String jpql = "Select cart from UserCart cart where cart.customerId = :id";
		TypedQuery<UserCart> query = manager.createQuery(jpql, UserCart.class);
		query.setParameter("id", id);
		list = (ArrayList<UserCart>) query.getResultList();
		return list;
	}

	// Getting wishlist details and adding to wishlist
	@Override
	public ArrayList<UserWishList> getWishListDetails(Integer id) {
		ArrayList<UserWishList> list = new ArrayList<>();
		String jpql = "Select wishlist from UserWishList wishlist where wishlist.customerId = :id";
		TypedQuery<UserWishList> query = manager.createQuery(jpql, UserWishList.class);
		query.setParameter("id", id);
		list = (ArrayList<UserWishList>) query.getResultList();
		return list;
	}

	// Logic for checkout for a perticular product
	@Override
	public UserOrder getOrderById(Integer id) {
		return manager.find(UserOrder.class, id);
	}

}
