package com.cg.capcart.exception;

public class CapCartException {

}
