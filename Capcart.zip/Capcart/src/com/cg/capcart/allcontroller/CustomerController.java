package com.cg.capcart.allcontroller;

import java.util.ArrayList;
import javax.servlet.ServletContext;
import javax.servlet.http.HttpServletRequest;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import com.cg.capcart.model.ActionCustomer;
import com.cg.capcart.model.AllProductsTable;
import com.cg.capcart.model.User;
import com.cg.capcart.model.UserCart;
import com.cg.capcart.model.UserOrder;
import com.cg.capcart.model.UserWishList;
import com.cg.capcart.service.IService;

@Controller
public class CustomerController {

	@Autowired
	IService service;

	// The first page for a customer/merchant
	@RequestMapping("/home")
	public String firstPage() {
		return "firstPageCustomer";
	}

	// Method for login
	@RequestMapping("/loginCust")
	public String loginCustomer() {
		return "userLoginPage";
	}

	// Method for registering a new User
	@RequestMapping("/registerCust")
	public String registerCustomer(Model model) {
		model.addAttribute("cust", new User());
		return "customerPage";
	}

	// Method to redirect user to login page after registering
	@RequestMapping("/redirect")
	public String redirectCustomer(Model model, @ModelAttribute("cust") User user) {
		service.registerNewCustomer(user);
		model.addAttribute("customerObject", new ActionCustomer());
		return "userLoginPage";
	}

	// Forgot Password screen
	@RequestMapping("/forgot")
	public String forgotPassward() {
		return "forgot";
	}

	// New Password screen is shown
	@RequestMapping("/forgotPass")
	public String newPassward(Model model, @RequestParam("uname") String uname) {
		String passward = service.forgotPassward(uname);
		model.addAttribute("pass", passward);
		return "newPass";
	}

	// Menu page for Customer
	@RequestMapping(name = "/optionsPage", method = RequestMethod.POST)
	public String customerProfile(Model model, @RequestParam("username") String uname,
			@RequestParam("passward") String passward, HttpServletRequest request) {
		ActionCustomer customer = service.validateCustomer(uname, passward);
		if (customer != null) {
			ServletContext context = request.getServletContext();
			context.setAttribute("customer", customer);
			return "CustomerProfile";
		} else
			return "loginPage";
	}

	// Redirecting to change password screen
	@RequestMapping("/changePass")
	public String changePassward() {
		return "changePassward";
	}

	// redirected to profile Screen
	@RequestMapping("redirectAgain")
	public String redirectToprofilePage(@RequestParam("uname") String uname, @RequestParam("pass") String passward) {
		service.changePassward(uname, passward);
		return "customerProfile";
	}

	// Profile page for the customer
	@RequestMapping("/profile")
	public String firstPageForUser(HttpServletRequest request, Model model,
			@ModelAttribute("customerObject") ActionCustomer customer) {
		ServletContext context = request.getServletContext();
		ActionCustomer cust = (ActionCustomer) context.getAttribute("customer");
		model.addAttribute("customerProfile", cust);
		return "customerProfile";
	}

	// all past orders of the customer
	@RequestMapping("/allorders")
	public String customerAllOrders(Model model, HttpServletRequest request) {
		ArrayList<UserOrder> list = new ArrayList<>();
		ServletContext context = request.getServletContext();
		ActionCustomer customer = (ActionCustomer) context.getAttribute("customer");
		list = service.getAllOrdersById(customer.getUserId());
		model.addAttribute("orders", list);
		return "customerAllOrders";
	}

	// Category of products
	@RequestMapping("/categoryProducts")
	public String customerProducts() {
		return "categories";
	}

	// All products related to a perticular category
	@RequestMapping("/products")
	public String ShowProductByCategory(Model model, @RequestParam("name") String category) {
		ArrayList<AllProductsTable> list = service.getAllProductsByName(category);
		model.addAttribute("productsList", list);
		return "products";
	}

	// Viewing of a perticular product
	@RequestMapping("/eachProduct")
	public String eachProductPage(Model model, @RequestParam("id") Integer id) {
		AllProductsTable product = service.getProductById(id);
		model.addAttribute("product", product);
		return "eachProduct";
	}

	// Adding a product to cart
	@RequestMapping("/addCart")
	public String addToCart(Model model, HttpServletRequest request) {
		ServletContext context = request.getServletContext();
		ActionCustomer cust = (ActionCustomer) context.getAttribute("customer");
		ArrayList<UserCart> list = service.getCartDetails(cust.getUserId());
		model.addAttribute("cartDetails", list);
		return "cart";
	}

	// @RequestMapping("buyAll")
	// public String buyAllInCart() {
	// ArrayList<UserOrder> list;
	// return "orderScreen";
	// }

	// Adding a product to wishlist
	@RequestMapping("/addWishList")
	public String addToWIshList(Model model, HttpServletRequest request) {
		ServletContext context = request.getServletContext();
		ActionCustomer cust = (ActionCustomer) context.getAttribute("customer");
		ArrayList<UserWishList> list = service.getWishListDetails(cust.getUserId());
		model.addAttribute("cartDetails", list);
		return "wishList";
	}

	// Ordering a perticular product
	@RequestMapping("/orderNow")
	public String orderNow(Model model) {

		return "orderScreen";
	}

}
