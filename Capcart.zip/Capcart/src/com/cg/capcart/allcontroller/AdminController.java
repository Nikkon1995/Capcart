package com.cg.capcart.allcontroller;

import java.util.ArrayList;

import javax.servlet.ServletContext;
import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import com.cg.capcart.model.ActionCustomer;
import com.cg.capcart.model.ActionMerchant;
import com.cg.capcart.model.AllProductsTable;
import com.cg.capcart.model.MerchantInfo;
import com.cg.capcart.model.MerchantCoupon;
import com.cg.capcart.model.MerchantDiscount;
import com.cg.capcart.model.User;
import com.cg.capcart.service.IService;

@Controller
public class AdminController {

	@Autowired
	IService service;

	// Admin login Page Redirect
	@RequestMapping("/login")
	public String login() {
		String view = "AdminLogin";
		return view;
	}

	// Login Page
	@RequestMapping(value = "/checkLogin", method = RequestMethod.POST)
	public String checkLoginDetails(@RequestParam("UName") String name, @RequestParam("Password") String pass) {
		String view = "";
		if ("admin".equalsIgnoreCase(name) && "admin".equals(pass))
			view = "home";
		else
			view = "AdminLogin";
		return view;
	}

	// Method for ActionMerchant button
	@RequestMapping("/acceptMerchant")
	public String merchantApproval(Model model) {
		String view = "merchantApproval";
		ArrayList<MerchantInfo> list = service.getAllMerchantApprovals();
		model.addAttribute("merchant", list);
		return view;
	}

	// Method for approving Merchant button
	@RequestMapping("/approveMerchant")
	public String merchantApproved(@RequestParam("id") Integer id, HttpServletRequest request) {
		service.approvedMerchant(id);
		ArrayList<MerchantInfo> list = service.getAllMerchantApprovals();
		// model.addAttribute("merchant", list);
		ServletContext context = request.getServletContext();
		context.setAttribute("merchant", list);
		return "merchantApproval";
	}

	// Method for declining Merchant button
	@RequestMapping("/deleteMerchant")
	public String merchantDecline(@RequestParam("id") Integer id, HttpServletRequest request) {
		service.declinedMerchant(id);
		ArrayList<MerchantInfo> list = service.getAllMerchantApprovals();
		// model.addAttribute("merchant", list);
		ServletContext context = request.getServletContext();
		context.setAttribute("merchant", list);
		return "merchantApproval";
	}

	// Button for viewing all existing merchants
	@RequestMapping("/AdminMerchant")
	public String merchantDetails(Model model, HttpServletRequest request) {
		ArrayList<ActionMerchant> list = service.getAllMerchant();
		// model.addAttribute("merchantObject", list);
		ServletContext context = request.getServletContext();
		context.setAttribute("merchantObject", list);
		return new String("allmerchant");
	}

	// Method for removing a merchant
	@RequestMapping("/removeMerchant")
	public String removeMerchantDetails(Model model, @RequestParam("id") Integer id, HttpServletRequest request) {
		service.removeMerchant(id);
		ArrayList<ActionMerchant> list = service.getAllMerchant();
		// model.addAttribute("merchantObject", list);
		ServletContext context = request.getServletContext();
		context.setAttribute("merchantObject", list);
		return new String("allmerchant");
	}

	// Button for all User approvals
	@RequestMapping("/acceptUser")
	public String userApproval(Model model) {
		String view = "userApproval";
		ArrayList<User> list = service.getAllUserApprovals();
		model.addAttribute("user", list);
		return view;
	}

	// Method for approving a new User
	@RequestMapping("/approveUser")
	public String userApproved(@RequestParam("id") Integer id, HttpServletRequest request) {
		service.approvedUser(id);
		ArrayList<User> list = service.getAllUserApprovals();
		ServletContext context = request.getServletContext();
		context.setAttribute("user", list);
		return "userApproval";
	}

	// Method for deleting a new User
	@RequestMapping("/deleteUser")
	public String userDecline(@RequestParam("id") Integer id, HttpServletRequest request) {
		service.declinedUser(id);
		ArrayList<User> list = service.getAllUserApprovals();
		ServletContext context = request.getServletContext();
		context.setAttribute("user", list);
		return "userApproval";
	}

	// Button for viewing all existing users
	@RequestMapping("/AdminCustomer")
	public String userdetails(Model model) {
		ArrayList<ActionCustomer> list = service.getAllCustomer();
		model.addAttribute("userObject", list);
		return new String("allusers");
	}

	// method for removing existing user
	@RequestMapping("/removeCustomer")
	public String removeCustomerDetails(Model model, @RequestParam("id") Integer id, HttpServletRequest request) {
		service.removeCustomer(id);
		ArrayList<ActionCustomer> list = service.getAllCustomer();
		ServletContext context = request.getServletContext();
		context.setAttribute("userObject", list);
		return new String("allusers");
	}

	// button for viewing all products
	@RequestMapping("/productdetails")
	public String productsDetails(Model model) {
		ArrayList<AllProductsTable> list = service.getAllProducts();
		model.addAttribute("productsObject", list);
		return "allproducts";
	}

	// method to remove all products
	@RequestMapping("/removeProduct")
	public String removeProductDetails(Model model, @RequestParam("id") Integer id) {
		service.removeProduct(id);
		return "allproducts";
	}

	// method for viewing coupons related to a product
	@RequestMapping("/showCoupons")
	public String showAllCoupons(Model model, @RequestParam("id") Integer id) {
		ArrayList<MerchantCoupon> list = service.getAllCoupons(id);
		model.addAttribute("couponsObject", list);
		return "allCoupons";
	}

	// method for viewing discounts related to a product
	@RequestMapping("/showDiscounts")
	public String showAllDiscounts(Model model, @RequestParam("id") Integer id) {
		ArrayList<MerchantDiscount> list = service.getAllDiscounts(id);
		model.addAttribute("discountsObject", list);
		return "allDiscounts";
	}
}
