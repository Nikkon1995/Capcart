package com.cg.capcart.allcontroller;

import org.springframework.stereotype.Controller;

//@Controller
public class MerchantController {

}
