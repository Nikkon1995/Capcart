package com.cg.capcart.model;

import javax.persistence.Entity;
import javax.persistence.Id;

@Entity
public class MerchantCoupon {

	@Id
	// @GeneratedValue(strategy = GenerationType.AUTO)
	private Integer couponId;
	private String couponValue;
	private Integer productId;
	private Integer discountedPrice;

	public MerchantCoupon() {

	}

	public MerchantCoupon(Integer couponId, String couponValue, Integer productId, Integer discountedPrice) {
		super();
		this.couponId = couponId;
		this.couponValue = couponValue;
		this.productId = productId;
		this.discountedPrice = discountedPrice;
	}

	public Integer getCouponId() {
		return couponId;
	}

	public void setCouponId(Integer couponId) {
		this.couponId = couponId;
	}

	public Integer getProductId() {
		return productId;
	}

	public void setProductId(Integer productId) {
		this.productId = productId;
	}

	public String getCouponValue() {
		return couponValue;
	}

	public void setCouponValue(String couponValue) {
		this.couponValue = couponValue;
	}

	public Integer getDiscountedPrice() {
		return discountedPrice;
	}

	public void setDiscountedPrice(Integer discountedPrice) {
		this.discountedPrice = discountedPrice;
	}

}
