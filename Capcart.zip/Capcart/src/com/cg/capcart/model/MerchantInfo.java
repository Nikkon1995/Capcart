package com.cg.capcart.model;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

@Entity

public class MerchantInfo {
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private Integer regId;
	private String merchantName;
	private String companyName;
	private String contactNo;
	private String merchantAddress;
	private String emailId;
	private String merchantUsername;
	private String merchantPassword;

	public MerchantInfo() {

	}

	public MerchantInfo(Integer regId, String merchantName, String companyName, String contactNo,
			String merchantAddress, String emailId, String merchantUsername, String merchantPassword) {
		super();
		this.regId = regId;
		this.merchantName = merchantName;
		this.companyName = companyName;
		this.contactNo = contactNo;
		this.merchantAddress = merchantAddress;
		this.emailId = emailId;
		this.merchantUsername = merchantUsername;
		this.merchantPassword = merchantPassword;
	}

	public Integer getRegId() {
		return regId;
	}

	public void setRegId(Integer regId) {
		this.regId = regId;
	}

	public String getMerchantName() {
		return merchantName;
	}

	public void setMerchantName(String merchantName) {
		this.merchantName = merchantName;
	}

	public String getCompanyName() {
		return companyName;
	}

	public void setCompanyName(String companyName) {
		this.companyName = companyName;
	}

	public String getContactNo() {
		return contactNo;
	}

	public void setContactNo(String contactNo) {
		this.contactNo = contactNo;
	}

	public String getMerchantAddress() {
		return merchantAddress;
	}

	public void setMerchantAddress(String merchantAddress) {
		this.merchantAddress = merchantAddress;
	}

	public String getEmailId() {
		return emailId;
	}

	public void setEmailId(String emailId) {
		this.emailId = emailId;
	}

	public String getMerchantUsername() {
		return merchantUsername;
	}

	public void setMerchantUsername(String merchantUsername) {
		this.merchantUsername = merchantUsername;
	}

	public String getMerchantPassword() {
		return merchantPassword;
	}

	public void setMerchantPassword(String merchantPassword) {
		this.merchantPassword = merchantPassword;
	}

}
