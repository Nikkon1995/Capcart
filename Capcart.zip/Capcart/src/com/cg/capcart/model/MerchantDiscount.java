package com.cg.capcart.model;

import javax.persistence.Entity;
import javax.persistence.Id;

@Entity
public class MerchantDiscount {

	@Id
	// @GeneratedValue(strategy = GenerationType.AUTO)
	private Integer discountId;
	private String discountRate;
	private Integer productId;

	public MerchantDiscount() {

	}

	public MerchantDiscount(Integer discountId, String discountRate, Integer productId) {
		super();
		this.discountId = discountId;
		this.discountRate = discountRate;
		this.productId = productId;
	}

	public Integer getDiscountId() {
		return discountId;
	}

	public void setDiscountId(Integer discountId) {
		this.discountId = discountId;
	}

	public Integer getProductId() {
		return productId;
	}

	public void setProductId(Integer productId) {
		this.productId = productId;
	}

	public String getDiscountRate() {
		return discountRate;
	}

	public void setDiscountRate(String discountRate) {
		this.discountRate = discountRate;
	}

}
