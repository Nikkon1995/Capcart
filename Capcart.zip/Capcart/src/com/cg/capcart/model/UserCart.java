package com.cg.capcart.model;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "Cart")
public class UserCart {

	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private Integer cartId;
	private String productId;
	private String productName;
	private String productDesciption;
	private String quantity;
	private String price;
	private Integer customerId;

	public UserCart() {

	}

	public UserCart(Integer cartId, String productId, String productName, String productDesciption, String quantity,
			String price, Integer customerId) {
		super();
		this.cartId = cartId;
		this.productId = productId;
		this.productName = productName;
		this.productDesciption = productDesciption;
		this.quantity = quantity;
		this.price = price;
		this.customerId = customerId;
	}

	public String getProductId() {
		return productId;
	}

	public void setProductId(String productId) {
		this.productId = productId;
	}

	public Integer getCartId() {
		return cartId;
	}

	public void setCartId(Integer cartId) {
		this.cartId = cartId;
	}

	public String getProductName() {
		return productName;
	}

	public void setProductName(String productName) {
		this.productName = productName;
	}

	public String getProductDesciption() {
		return productDesciption;
	}

	public void setProductDesciption(String productDesciption) {
		this.productDesciption = productDesciption;
	}

	public String getQuantity() {
		return quantity;
	}

	public void setQuantity(String quantity) {
		this.quantity = quantity;
	}

	public String getPrice() {
		return price;
	}

	public void setPrice(String price) {
		this.price = price;
	}

	public Integer getCustomerId() {
		return customerId;
	}

	public void setCustomerId(Integer customerId) {
		this.customerId = customerId;
	}

}
