package com.cg.capcart.model;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

@Entity
public class UserTransaction {

	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private Integer transacId;
	private String productId;
	private String productName;
	private String productQuantity;
	private String productPrice;

	public UserTransaction() {

	}

	public UserTransaction(Integer transacId, String productId, String productName, String productQuantity,
			String productPrice) {
		super();
		this.transacId = transacId;
		this.productId = productId;
		this.productName = productName;
		this.productQuantity = productQuantity;
		this.productPrice = productPrice;
	}

	public Integer getTransacId() {
		return transacId;
	}

	public void setTransacId(Integer transacId) {
		this.transacId = transacId;
	}

	public String getProductId() {
		return productId;
	}

	public void setProductId(String productId) {
		this.productId = productId;
	}

	public String getProductName() {
		return productName;
	}

	public void setProductName(String productName) {
		this.productName = productName;
	}

	public String getProductQuantity() {
		return productQuantity;
	}

	public void setProductQuantity(String productQuantity) {
		this.productQuantity = productQuantity;
	}

	public String getProductPrice() {
		return productPrice;
	}

	public void setProductPrice(String productPrice) {
		this.productPrice = productPrice;
	}

}
