package com.cg.capcart.model;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

@Entity
public class UserFeedback {

	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private Integer id;
	private String feedbackDesc;
	private String feedbackRating;

	public UserFeedback() {

	}

	public UserFeedback(Integer id, String feedbackDesc, String feedbackRating) {
		super();
		this.id = id;
		this.feedbackDesc = feedbackDesc;
		this.feedbackRating = feedbackRating;
	}

	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public String getFeedbackDesc() {
		return feedbackDesc;
	}

	public void setFeedbackDesc(String feedbackDesc) {
		this.feedbackDesc = feedbackDesc;
	}

	public String getFeedbackRating() {
		return feedbackRating;
	}

	public void setFeedbackRating(String feedbackRating) {
		this.feedbackRating = feedbackRating;
	}

}
