package com.cg.capcart.model;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

@Entity
public class UserCategories {

	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private String id;
	private String luggage;
	private String menClothing;
	private String womenClothing;
	private String electronics;
	private String home;
	private String books;
	private String movies;
	private String television;
	private String groceries;

	public UserCategories() {

	}

	public UserCategories(String id, String luggage, String menClothing, String womenClothing, String electronics,
			String home, String books, String movies, String television, String groceries) {
		super();
		this.id = id;
		this.luggage = luggage;
		this.menClothing = menClothing;
		this.womenClothing = womenClothing;
		this.electronics = electronics;
		this.home = home;
		this.books = books;
		this.movies = movies;
		this.television = television;
		this.groceries = groceries;
	}

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getLuggage() {
		return luggage;
	}

	public void setLuggage(String luggage) {
		this.luggage = luggage;
	}

	public String getMenClothing() {
		return menClothing;
	}

	public void setMenClothing(String menClothing) {
		this.menClothing = menClothing;
	}

	public String getWomenClothing() {
		return womenClothing;
	}

	public void setWomenClothing(String womenClothing) {
		this.womenClothing = womenClothing;
	}

	public String getElectronics() {
		return electronics;
	}

	public void setElectronics(String electronics) {
		this.electronics = electronics;
	}

	public String getHome() {
		return home;
	}

	public void setHome(String home) {
		this.home = home;
	}

	public String getBooks() {
		return books;
	}

	public void setBooks(String books) {
		this.books = books;
	}

	public String getMovies() {
		return movies;
	}

	public void setMovies(String movies) {
		this.movies = movies;
	}

	public String getTelevision() {
		return television;
	}

	public void setTelevision(String television) {
		this.television = television;
	}

	public String getGroceries() {
		return groceries;
	}

	public void setGroceries(String groceries) {
		this.groceries = groceries;
	}

}
