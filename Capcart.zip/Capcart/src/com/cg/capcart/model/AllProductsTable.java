package com.cg.capcart.model;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

@Entity
public class AllProductsTable {

	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private Integer productId;
	private String merchantName;
	private String productName;
	private String productDesciption;
	private String productPrice;
	private Integer couponId;
	private Integer discountId;
	private String category;

	public AllProductsTable() {

	}

	public AllProductsTable(Integer productId, String merchantName, String productName, String productDesciption,
			String productPrice, Integer couponId, Integer discountId, String category) {
		super();
		this.productId = productId;
		this.merchantName = merchantName;
		this.productName = productName;
		this.productDesciption = productDesciption;
		this.productPrice = productPrice;
		this.couponId = couponId;
		this.discountId = discountId;
		this.category = category;
	}

	public Integer getProductId() {
		return productId;
	}

	public void setProductId(Integer productId) {
		this.productId = productId;
	}

	public String getMerchantName() {
		return merchantName;
	}

	public void setMerchantName(String merchantName) {
		this.merchantName = merchantName;
	}

	public String getProductName() {
		return productName;
	}

	public void setProductName(String productName) {
		this.productName = productName;
	}

	public String getProductDesciption() {
		return productDesciption;
	}

	public void setProductDesciption(String productDesciption) {
		this.productDesciption = productDesciption;
	}

	public String getProductPrice() {
		return productPrice;
	}

	public void setProductPrice(String productPrice) {
		this.productPrice = productPrice;
	}

	public Integer getCouponId() {
		return couponId;
	}

	public void setCouponId(Integer couponId) {
		this.couponId = couponId;
	}

	public Integer getDiscountId() {
		return discountId;
	}

	public void setDiscountId(Integer discountId) {
		this.discountId = discountId;
	}

	public String getCategory() {
		return category;
	}

	public void setCategory(String category) {
		this.category = category;
	}

}
