package com.cg.capcart.service;

import java.util.ArrayList;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.cg.capcart.dao.IDao;
import com.cg.capcart.model.ActionCustomer;
import com.cg.capcart.model.ActionMerchant;
import com.cg.capcart.model.AllProductsTable;
import com.cg.capcart.model.MerchantInfo;
import com.cg.capcart.model.MerchantCoupon;
import com.cg.capcart.model.MerchantDiscount;
import com.cg.capcart.model.User;
import com.cg.capcart.model.UserCart;
import com.cg.capcart.model.UserOrder;
import com.cg.capcart.model.UserWishList;

@Service
@Transactional
public class ServiceImpl implements IService {

	@Autowired
	IDao dao;

	@Override
	public ArrayList<ActionMerchant> getAllMerchant() {
		return dao.getAllMerchant();
	}

	@Override
	public String removeMerchant(Integer id) {
		return dao.removeMerchant(id);
	}

	@Override
	public ArrayList<ActionCustomer> getAllCustomer() {
		return dao.getAllCustomer();
	}

	@Override
	public String removeCustomer(Integer id) {
		return dao.removeCustomer(id);
	}

	@Override
	public ArrayList<AllProductsTable> getAllProducts() {
		return dao.getAllProducts();
	}

	@Override
	public String removeProduct(Integer id) {
		return dao.removeProduct(id);
	}

	@Override
	public ArrayList<MerchantInfo> getAllMerchantApprovals() {
		return dao.getAllMerchantApprovals();
	}

	@Override
	public void approvedMerchant(Integer id) {
		dao.approvedMerchant(id);
	}

	@Override
	public void declinedMerchant(Integer id) {
		dao.declinedMerchant(id);
	}

	@Override
	public ArrayList<User> getAllUserApprovals() {
		return dao.getAllUserApprovals();
	}

	@Override
	public void approvedUser(Integer id) {
		dao.approvedUser(id);
	}

	@Override
	public void declinedUser(Integer id) {
		dao.declinedUser(id);
	}

	@Override
	public ArrayList<MerchantCoupon> getAllCoupons(Integer id) {
		return dao.getAllCoupons(id);
	}

	@Override
	public ArrayList<MerchantDiscount> getAllDiscounts(Integer id) {
		return dao.getAllDiscounts(id);
	}

	@Override
	public ArrayList<UserOrder> getAllOrdersById(Integer userId) {
		return dao.getAllOrdersById(userId);
	}

	@Override
	public ArrayList<AllProductsTable> getAllProductsByName(String category) {
		return dao.getAllProductsByName(category);
	}

	@Override
	public AllProductsTable getProductById(Integer id) {
		return dao.getProductById(id);
	}

	@Override
	public ArrayList<UserCart> getCartDetails(Integer id) {
		return dao.getCartDetails(id);
	}

	@Override
	public ArrayList<UserWishList> getWishListDetails(Integer id) {
		return dao.getWishListDetails(id);
	}

	@Override
	public UserOrder getOrderById(Integer id) {
		return dao.getOrderById(id);
	}

	@Override
	public ActionCustomer validateCustomer(String uname, String passward) {
		return dao.validateCustomer(uname, passward);
	}

	@Override
	public void registerNewCustomer(User user) {
		dao.registerNewCustomer(user);
	}

	@Override
	public String forgotPassward(String uname) {
		return dao.forgotPassward(uname);
	}

	@Override
	public void changePassward(String uname, String passward) {
		dao.changePassward(uname, passward);
	}

}
