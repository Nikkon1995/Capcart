package com.cg.capcart.service;

import java.util.ArrayList;

import com.cg.capcart.model.ActionCustomer;
import com.cg.capcart.model.ActionMerchant;
import com.cg.capcart.model.AllProductsTable;
import com.cg.capcart.model.MerchantInfo;
import com.cg.capcart.model.MerchantCoupon;
import com.cg.capcart.model.MerchantDiscount;
import com.cg.capcart.model.User;
import com.cg.capcart.model.UserCart;
import com.cg.capcart.model.UserOrder;
import com.cg.capcart.model.UserWishList;

public interface IService {

	ArrayList<ActionMerchant> getAllMerchant();

	String removeMerchant(Integer id);

	ArrayList<ActionCustomer> getAllCustomer();

	String removeCustomer(Integer id);

	ArrayList<AllProductsTable> getAllProducts();

	String removeProduct(Integer id);

	ArrayList<MerchantInfo> getAllMerchantApprovals();

	void approvedMerchant(Integer id);

	void declinedMerchant(Integer id);

	ArrayList<User> getAllUserApprovals();
	
	void approvedUser(Integer id);

	void declinedUser(Integer id);

	ArrayList<MerchantCoupon> getAllCoupons(Integer id);

	ArrayList<MerchantDiscount> getAllDiscounts(Integer id);

	ArrayList<UserOrder> getAllOrdersById(Integer userId);

	ArrayList<AllProductsTable> getAllProductsByName(String category);

	AllProductsTable getProductById(Integer id);

	ArrayList<UserCart> getCartDetails(Integer id);

	ArrayList<UserWishList> getWishListDetails(Integer id);

	UserOrder getOrderById(Integer id);

	ActionCustomer validateCustomer(String uname, String passward);

	void registerNewCustomer(User user);

	String forgotPassward(String uname);

	void changePassward(String uname, String passward);
}
