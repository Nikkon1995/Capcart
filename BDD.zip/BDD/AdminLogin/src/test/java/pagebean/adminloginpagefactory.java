package pagebean;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.CacheLookup;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class adminloginpagefactory {
	
	WebDriver driver;
	@FindBy(id="txtUserName")
	@CacheLookup
	WebElement pfname;
	
	@FindBy(id="txtPassword")
	@CacheLookup
	WebElement pfpwd;
	
	@FindBy(id="btnRegister")
	@CacheLookup
	WebElement pfregister;

	public WebElement getPfname() {
		return pfname;
	}

	public void setPfname(String sfname) {
		pfname.sendKeys(sfname);
	}

	public WebElement getPfpwd() {
		return pfpwd;
	}

	public void setPfpwd(String sfpwd) {
		pfpwd.sendKeys(sfpwd);
	}

	public WebElement getPfregister() {
		return pfregister;
	}

	public void setPfregister() {
		pfregister.click();
	}
	
	public adminloginpagefactory(WebDriver driver) {
		this.driver = driver;
		PageFactory.initElements(driver, this);
	}
	

}
