package adminlogin;

import org.junit.Assert;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;


import cucumber.api.java.Before;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import pagebean.adminloginpagefactory;

public class StepDef {
	private static WebDriver driver;
	private adminloginpagefactory factory;
	String BaseURL,NodeURL;
	@Before
	public void beforeLogin()
	{
		System.setProperty("webdriver.chrome.driver", "D:\\webdriver\\chromedriver.exe");
		driver = new ChromeDriver();
	}
	@Given("^User is on the admin login page$")
	public void user_is_on_the_admin_login_page() throws Throwable {
		System.out.println("driver = "+driver);
		factory = new adminloginpagefactory(driver);
		driver.get("file:///C:/Users/admin/Desktop/plp%20pages/Admin/AdminLogin.html");
	}

	@When("^User enters valid username and valid password$")
	public void user_enters_valid_username_and_valid_password() throws Throwable {
	    factory.setPfname("Admin");
	    Thread.sleep(1000);
	    factory.setPfpwd("Admin");
	    Thread.sleep(1000);
	    factory.setPfregister();
	}

	@Then("^navigate to admin homepage$")
	public void navigate_to_admin_homepage() throws Throwable {
		driver.get("file:///C:/Users/admin/Desktop/plp%20pages/Admin/adminHome.html");
	}

	@When("^User gives empty username$")
	public void user_gives_empty_username() throws Throwable {
	    factory.setPfname("");
	    Thread.sleep(1000);
	    factory.setPfpwd("Admin");
	    Thread.sleep(1000);
	    factory.setPfregister();
	}

	@Then("^display 'Please enter username'$")
	public void display_Please_enter_username() throws Throwable {
		Assert.assertEquals(driver.switchTo().alert().getText(),"Please Enter Username");
	}

	@When("^User gives empty password$")
	public void user_gives_empty_password() throws Throwable {
		 factory.setPfname("Admin");
		 Thread.sleep(1000);
		 factory.setPfpwd("");
		 Thread.sleep(1000);
		 factory.setPfregister();
	}

	@Then("^display 'Please enter password'$")
	public void display_Please_enter_password() throws Throwable {
		Assert.assertEquals(driver.switchTo().alert().getText(),"Please Enter Password");
	}

	@When("^User gives invalid username$")
	public void user_gives_invalid_username() throws Throwable {
		factory.setPfname("6587575");
		Thread.sleep(1000);
		 factory.setPfpwd("Admin");
		 Thread.sleep(1000);
		 factory.setPfregister();
	}

	@Then("^display 'Please enter valid username'$")
	public void display_Please_enter_valid_username() throws Throwable {
		Assert.assertEquals(driver.switchTo().alert().getText(),"Please enter valid Name with min 5 letters");
	}

	@When("^User gives invalid password$")
	public void user_gives_invalid_password() throws Throwable {
		factory.setPfname("Admin");
		Thread.sleep(1000);
		factory.setPfpwd("7676968686");
		Thread.sleep(1000);
		factory.setPfregister();
	}
	

	@Then("^display 'Please enter valid password'$")
	public void display_Please_enter_valid_password() throws Throwable {
		Assert.assertEquals(driver.switchTo().alert().getText(),"Please Enter Valid User Id and Password");
	}

}
