package PageBean;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.CacheLookup;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class forgotPageFactory {
	WebDriver driver;
	
	@FindBy(name="Name")
	@CacheLookup
	WebElement pfname;
	

	@FindBy(id="btnRegister")
	@CacheLookup
	WebElement pfbtn;
	
	
	
	public WebElement getPfname() {
		return pfname;
	}



	public WebElement getPfbtn() {
		return pfbtn;
	}


	

	public void setPfname(String sname) {
		pfname.sendKeys(sname);
	}



	public void setPfbtn() {
		pfbtn.click();;
	}



	public forgotPageFactory(WebDriver driver) {
		this.driver = driver;
		PageFactory.initElements(driver, this);
	}

	
	
}
