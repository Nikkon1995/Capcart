package forgotPassword;

import java.sql.Driver;
import java.util.concurrent.TimeUnit;

import org.junit.Assert;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

import PageBean.forgotPageFactory;
import cucumber.api.PendingException;
import cucumber.api.java.After;
import cucumber.api.java.Before;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;



public class forgotStepDef {
	private static WebDriver driver;
	private forgotPageFactory factory;
	String BaseURL, NodeURL;
	
	@Before
	public void beforeLogin() {
		System.setProperty("webdriver.chrome.driver", "D:\\chromedriver.exe");
		driver = new ChromeDriver();
	}

	@Given("^User is on Forgot Password page$")
	public void user_is_on_Forgot_Password_page() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		System.out.println("driver = " + driver);
		factory = new forgotPageFactory(driver);

		driver.get("file:///C:/Users/admin/Desktop/MPT/Plp%20Web%20Pages/ForgotPassword.html");
	}

	@Then("^check the heading of the page$")
	public void check_the_heading_of_the_page() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		String title=driver.getTitle();
		if(title.contentEquals("Forgot Password")) System.out.println("****** Title Matched ******");
		else System.out.println("****** Title NOT Matched ******");
		driver.manage().timeouts().implicitlyWait(70, TimeUnit.SECONDS);
		driver.close();
	}

	@Given("^User is on 'Forgot Password' Page$")
	public void user_is_on_Forgot_Password_Page() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		System.out.println("driver = " + driver);
		factory = new forgotPageFactory(driver);

		driver.get("file:///C:/Users/admin/Desktop/MPT/Plp%20Web%20Pages/ForgotPassword.html");
	}

	@When("^user enters empty User Name$")
	public void user_enters_empty_User_Name() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		factory.setPfname("");
		factory.setPfbtn();
		//driver.close();
	}

	@Then("^display 'Please Enter User Name'$")
	public void display_Please_Enter_User_Name() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		Assert.assertEquals(driver.switchTo().alert().getText(), "Please fill the User Name.");
	}

	@When("^user enters invalid User Name$")
	public void user_enters_invalid_User_Name() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		factory.setPfname("987456");
		factory.setPfbtn();
		//driver.close();
	}
	
	@Then("^display 'Please Enter valid User Name'$")
	public void display_Please_Enter_valid_User_Name() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		Assert.assertEquals(driver.switchTo().alert().getText(), "Name should start with caps and must contain alphabets only");
	}

	@When("^user enters valid User Name$")
	public void user_enters_valid_User_Name() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		factory.setPfname("Rashmi");
		factory.setPfbtn();
		//driver.close();
		
	}

	@Then("^display 'New Password' Page$")
	public void display_New_Password_Page() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		//driver.switchTo().alert().accept();	
		driver.navigate().forward();
		//driver.close();
	}

	

}
