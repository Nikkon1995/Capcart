package Pagebean;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.CacheLookup;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;

public class UserSigninPageFactory {

WebDriver driver;
	
	//step 1 : identify elements
	@FindBy(name="Name")
	@CacheLookup
	WebElement pfname;

		@FindBy(id="txtPassword")
		@CacheLookup
		WebElement pfpwd;
	

	@FindBy(className="btn")
	@CacheLookup
	WebElement pfsignin;
	

	@FindBy(xpath="html/body/form/table/tbody/tr[5]/td/input")
	@CacheLookup
	WebElement pffp;
	

	@FindBy(xpath="html/body/form/table/tbody/tr[4]/td/a[1]")
	@CacheLookup
	WebElement pfsu;

	//initiating the elements
	public UserSigninPageFactory(WebDriver driver) {
		this.driver = driver;
		PageFactory.initElements(driver, this);
	}
	
	//setters
			public void setPfname(String sname) {
				pfname.sendKeys(sname);
			}
			
			public void setPfpwd(String spwd) {
				pfpwd.sendKeys(spwd);
			}
			public void setPfsignin() {
				pfsignin.click();
			}
			public void setPffp() {
				pffp.click();
			}
			public void setPfsu() {
				pfsu.click();
			}

			public WebElement getPfname() {
				return pfname;
			}

			public WebElement getPfpwd() {
				return pfpwd;
			}
			public WebElement getPffp() {
				 return pffp;
			}
			public WebElement getPfsu() {
				 return pfsu;
			}
		
		
	
}
