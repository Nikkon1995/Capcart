package UserSignin;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

import Pagebean.UserSigninPageFactory;
import cucumber.api.PendingException;
import cucumber.api.java.Before;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;



public class StepDef {
	private WebDriver driver;
	private UserSigninPageFactory obj;
	
	@Before
	public void openBrowser() {
		System.setProperty("webdriver.chrome.driver","D:\\chromedriver\\chromedriver.exe");
	driver = new ChromeDriver();
	driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
	obj = new UserSigninPageFactory(driver);
	driver.get("file:///C:/Users/admin/Desktop/webpages/SignInUser.html");
	}

	@Given("^user is on Login page$")
	public void user_is_on_Login_page() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	   // throw new PendingException();
		System.setProperty("webdriver.chrome.driver","D:\\chromedriver//chromedriver.exe");
		driver = new ChromeDriver();
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		obj = new UserSigninPageFactory(driver);
		driver.get("file:///C:/Users/admin/Desktop/webpages/SignInUser.html");

	}

	@When("^user leaves FullName blank and clicks on create account$")
	public void user_leaves_FullName_blank_and_clicks_on_create_account() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    //throw new PendingException();
		obj.setPfname("");
	    obj.setPfsignin();

	}

	@Then("^Display Please fill the FullName$")
	public void display_Please_fill_the_FullName() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    //throw new PendingException();
		String alertMessage = driver.switchTo().alert().getText();
		Thread.sleep(1000);
		driver.switchTo().alert().accept();
	    System.out.println(alertMessage);
	    driver.close();

	}

	@When("^user leaves Password blank and clicks on  create account$")
	public void user_leaves_Password_blank_and_clicks_on_create_account() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	   // throw new PendingException();
		obj.setPfname("Kavya");
		obj.setPfpwd("");
	    obj.setPfsignin();

	}

	@Then("^Display Please fill the Password$")
	public void display_Please_fill_the_Password() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	   // throw new PendingException();
		String alertMessage = driver.switchTo().alert().getText();
		Thread.sleep(1000);
		driver.switchTo().alert().accept();
	    System.out.println(alertMessage);
	    driver.close();


	}

	@When("^user enters valid data$")
	public void user_enters_valid_data() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	   // throw new PendingException();
		obj.setPfname("Kavya");
		obj.setPfpwd("kavya123");
	    obj.setPfsignin();


	}

	@Then("^Display \"([^\"]*)\"$")
	public void display(String arg1) throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    //throw new PendingException();
		driver.get("file:///C:/Users/admin/Desktop/webpages/success.html");
	}

	@When("^user enters Full Name$")
	public void user_enters_Full_Name() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    //throw new PendingException();
		obj.setPfname("Kavya");
	}

	@Then("^clicks on forgotpassword and navigate to forgotpassword page$")
	public void clicks_on_forgotpassword_and_navigate_to_forgotpassword_page() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	   // throw new PendingException();
		driver.get("file:///C:/Users/admin/Desktop/webpages/ForgotPassword.html");
	}
	
	@When("^user clicks on NewUser signup$")
	public void user_clicks_on_NewUser_signup() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	   // throw new PendingException();
		obj.setPfsu();
	}

	@Then("^navigate to UserSignup page$")
	public void navigate_to_UserSignup_page() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    //throw new PendingException();
		driver.get("file:///C:/Users/admin/Desktop/webpages/SignUpUser.html");
	}

	
	// TODO Auto-generated method stub
		
}
