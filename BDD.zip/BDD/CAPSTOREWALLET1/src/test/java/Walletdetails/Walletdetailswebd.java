package Walletdetails;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class Walletdetailswebd {
	
	static WebDriver driver=null;
	static String alertMessage=null;
	public static void main(String[] args) {
		
		driver=new ChromeDriver();
		driver.get("file:///C:/Users/admin/Desktop/Plp/capstorewallet.html");
		
		String title=driver.getTitle();
		System.out.println("The page title is :" + title);
		
		/******* For blank Amount *******/
		driver.findElement(By.name("txtM")).sendKeys("");
		driver.findElement(By.id("btnRegister")).click();	
		callAlert();
		
		/******* For valid Amount *******/
		driver.findElement(By.name("txtM")).sendKeys("500");
	}
		
		public static void callAlert()
		{
			String alertMessage= driver.switchTo().alert().getText();
			System.out.println(alertMessage);		
			driver.switchTo().alert().accept();

		}

}
