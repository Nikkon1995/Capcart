package Walletdetails;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

import PageBean.WalletRegistration;

import cucumber.api.java.Before;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class Stepdefwallet {
	private  WebDriver driver;
	private WalletRegistration objhlpg;
	String BaseURL,NodeURL;
	
	@Before
	public void beforeLogin()
	{
		System.setProperty("webdriver.chrome.driver","C:\\Users\\admin\\Desktop\\module3\\New folder\\chromedriver_win32/chromedriver.exe");
		driver= new ChromeDriver();
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		
		}
	
	@Given("^User is on 'Add Balance' Page$")
	public void user_is_on_Add_Balance_Page() throws Throwable {
		System.out.println("driver = "+driver);
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		objhlpg = new WalletRegistration();

		driver.get("file:///C:/Users/admin/Desktop/Plp/capstorewallet.html");
	}

	@When("^user does not enter the amount to be added$")
	public void user_does_not_enter_the_amount_to_be_added() throws Throwable {
		objhlpg.setPffmoney("");	Thread.sleep(1000);
	}

	@When("^Clicks the button$")
	public void clicks_the_button() throws Throwable {
		 objhlpg.setPfbutton();
	}

	@Then("^display alert msg$")
	public void display_alert_msg() throws Throwable {
		String alertMessage = driver.switchTo().alert().getText();
		Thread.sleep(1000);
		driver.switchTo().alert().accept();
	    System.out.println("*******" + alertMessage);
	    //driver.close();
	}

}
