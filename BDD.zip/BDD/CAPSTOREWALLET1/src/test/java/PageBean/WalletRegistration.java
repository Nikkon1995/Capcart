package PageBean;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.CacheLookup;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;

public class WalletRegistration {
	WebDriver driver;
	//step 1 : identify elements
			@FindBy(name="txtM")
			@CacheLookup
			WebElement pffmoney;
			
			//using how class
			@FindBy(how=How.ID, using="btnRegister")
			@CacheLookup
			WebElement pfbutton;
			

			//initiating the elements
			public void HotelLoginPageFactory(WebDriver driver) {
				this.driver = driver;
				PageFactory.initElements(driver, this);
			
			}


			


			public void setPffmoney(String money) {
				pffmoney.sendKeys(money);
			}


			public void setPfbutton() {
				pfbutton.click();
			}


			


			public WebElement getPffmoney() {
				return pffmoney;
			}


			public WebElement getPfbutton() {
				return pfbutton;
			}
			

}
