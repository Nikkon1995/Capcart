package AddressFeature;

import java.util.List;
import java.util.concurrent.TimeUnit;
import java.util.regex.Pattern;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

import AddrPageBean.AddrPageFactory;
import cucumber.api.DataTable;
import cucumber.api.java.Before;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class StepDefAddr {
	
	private WebDriver driver;
	private AddrPageFactory obj;
	
	@Before
	public void openBrowser() {
		System.setProperty("webdriver.chrome.driver","D:\\chromedriver\\chromedriver.exe");
	driver = new ChromeDriver();
	driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
	obj = new AddrPageFactory(driver);
	driver.get("file:///C:/Users/admin/Desktop/Capc%20page/cashondelivery.html");
	}
	
	@Given("^user is cod page$")
	public void user_is_cod_page() throws Throwable {
		System.setProperty("webdriver.chrome.driver","D:\\chromedriver//chromedriver.exe");
		driver = new ChromeDriver();
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		obj = new AddrPageFactory(driver);
		driver.get("file:///C:/Users/admin/Desktop/Capc%20page/cashondelivery.html");
	}

	@When("^user enter valid data$")
	public void user_enter_valid_data() throws Throwable {
		obj.setUN("Ranganathan");
	    obj.setEmail("rana123@gmail.com");
	    obj.setPhone("9876543210");
	    obj.setAdd("Room no:3,Kailash Complex,Mumbai");
	    obj.setNext();
	    
	}

	@Then("^navigate$")
	public void navigate() throws Throwable {
		driver.navigate().to("file:///C:/Users/admin/Desktop/Capc%20page/codsuccess.html");
		driver.manage().timeouts().implicitlyWait(5, TimeUnit.SECONDS);
		driver.close();
	}

	@When("^user leaves username blank$")
	public void user_leaves_username_blank() throws Throwable {
		obj.setUN("");
	    obj.setNext();
	}

	@Then("^display error message$")
	public void display_error_message() throws Throwable {
		callAlert();
	}

	@When("^user enters valid username and not entering others$")
	public void user_enters_valid_username_and_not_entering_others() throws Throwable {
		obj.setUN("Ranganathan");
	    obj.setNext();
	    callAlert();
	}

	@When("^user leaves Email blank$")
	public void user_leaves_Email_blank() throws Throwable {
		obj.setUN("Ranganathan");		
		obj.setEmail("");
	    obj.setNext();
	    callAlert();
	}

	@When("^user enters valid Email and not entering others$")
	public void user_enters_valid_Email_and_not_entering_others() throws Throwable {
		obj.setUN("Ranganathan");
		obj.setEmail("rana123@gmail.com");
	    obj.setNext();
	    callAlert();
	}

	@When("^user leaves Mobile no blank$")
	public void user_leaves_Mobile_no_blank() throws Throwable {
		obj.setUN("Ranganathan");
		obj.setEmail("rana123@gmail.com");
		obj.setPhone("");
	    obj.setNext();
	    callAlert();
	}

	@When("^user enters incorrect mobileNo format and clicks the button$")
	public void user_enters_incorrect_mobileNo_format_and_clicks_the_button(DataTable arg1) throws Throwable {
		obj.setUN("Ranganathan");
		obj.setEmail("rana123@gmail.com");
		obj.setPhone("");
		List<String> objList = arg1.asList(String.class);
		//objhbpg.setPfmobile(objList);	Thread.sleep(1000);
		obj.setNext();
		
		for(int i=0; i<objList.size(); i++) {
			if(Pattern.matches("^[7-9]{1}[0-9]{9}$", objList.get(i))) {
			System.out.println("***** Matched" + objList.get(i) + "*****");
			}
			else {
				System.out.println("***** NOT Matched" + objList.get(i) + "*****");
			}
		}
	}

	@Then("^error$")
	public void error() throws Throwable {
		callAlert();
	}

	@When("^user enters valid Mobile no and not entering others$")
	public void user_enters_valid_Mobile_no_and_not_entering_others() throws Throwable {
		obj.setUN("Ranganathan");
		obj.setEmail("rana123@gmail.com");
		obj.setPhone("9874563210");
	    obj.setNext();		
	    callAlert();
	}

	@When("^user leaves Address blank$")
	public void user_leaves_Address_blank() throws Throwable {
		obj.setUN("Ranganathan");
		obj.setEmail("rana123@gmail.com");
		obj.setPhone("9874563210");
		obj.setAdd("");
	    obj.setNext();		
	    callAlert();
	}

	@When("^user gives valid address$")
	public void user_gives_valid_address() throws Throwable {
		obj.setUN("Ranganathan");
		obj.setEmail("rana123@gmail.com");	
		obj.setPhone("9874563210");
		obj.setAdd("Room no:3,Kailash Complex,Mumbai");
	    obj.setNext();
		driver.navigate().to("file:///C:/Users/admin/Desktop/Capc%20page/codsuccess.html");
		driver.manage().timeouts().implicitlyWait(5, TimeUnit.SECONDS);
		driver.close();
	    
	}
	public void callAlert() {
		String alertMessage = driver.switchTo().alert().getText();
		
	    System.out.println("******" + alertMessage);
	    System.out.println("Please enter valid data");
	    driver.switchTo().alert().accept();
	   
		
	}


}
