package AddrPageBean;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.CacheLookup;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class AddrPageFactory {
	
WebDriver driver;
	
	
	@FindBy(id ="txtUserName")
	@CacheLookup
	WebElement eun;
	
	@FindBy(id ="txtEmail")
	@CacheLookup
	WebElement email;
	
	@FindBy(id="txtPhone")
	@CacheLookup
	WebElement eph;
	
	@FindBy(id ="txtAddress")
	@CacheLookup
	WebElement eadd;
	
	@FindBy(id ="btncod")
	@CacheLookup
	WebElement enext;
	
	public void setUN(String value)
	{
		eun.sendKeys(value);
	}
	
	public void setEmail(String value)
	{
		email.sendKeys(value);
	}
	
	public void setPhone(String value)
	{
		eph.sendKeys(value);
	}
	
	public void setAdd(String value)
	{
		eadd.sendKeys(value);
	}
	
	public void setNext()
	{
		enext.click();
	}
	
	
	public AddrPageFactory(WebDriver driver) {
		this.driver = driver;
		PageFactory.initElements(driver, this);
	}

}
