package ChangePassword;

import org.junit.Assert;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

import PageBean.PasswordChangeBean;
import cucumber.api.java.After;
import cucumber.api.java.Before;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class ChangePasswordStepDef {

	private static WebDriver driver;
	private PasswordChangeBean objhbpg;
	String BaseURL, NodeURL;

	@Before
	public void beforeLogin() {
		System.setProperty("webdriver.chrome.driver", "D:\\chromedriver.exe");
		driver = new ChromeDriver();

	}

	@Given("^User is on 'ChangePassword' Page$")
	public void user_is_on_ChangePassword_Page() throws Throwable {
		System.out.println("driver = " + driver);
		objhbpg = new PasswordChangeBean(driver);
		driver.get("file:///C:/Users/admin/Desktop/changepass.html");
	}

	@When("^user clicks Save Without 'UserName'$")
	public void user_clicks_Save_Without_UserName() throws Throwable {
		objhbpg.setPffuname("");
		objhbpg.setPfbutton();
		Thread.sleep(1000);
	}

	@Then("^display 'Please Enter userName'$")
	public void display_Please_Enter_userName() throws Throwable {
		Assert.assertEquals(driver.switchTo().alert().getText(), "Please Enter UserName");
	}

	@When("^user clicks Save Without 'Password'$")
	public void user_clicks_Save_Without_Password() throws Throwable {
		objhbpg.setPffuname("Srinivas");
		objhbpg.setPfpswd("");
		objhbpg.setPfbutton();
		Thread.sleep(1000);
	}

	@Then("^display 'Please Enter Password'$")
	public void display_Please_Enter_Password() throws Throwable {
		Assert.assertEquals(driver.switchTo().alert().getText(), "Please Enter Password");
	}

	@When("^user clicks Save Without 'confirmPassword'$")
	public void user_clicks_Save_Without_confirmPassword() throws Throwable {
		objhbpg.setPffuname("Srinivas");
		objhbpg.setPfpswd("Srinivas123");
		objhbpg.setPfcnfpswd("");
		objhbpg.setPfbutton();
		Thread.sleep(1000);
	}

	@Then("^display 'Please Enter confirmPassword'$")
	public void display_Please_Enter_confirmPassword() throws Throwable {
		Assert.assertEquals(driver.switchTo().alert().getText(), "Re-enter your password");
	}
	@When("^user clicks Save entering wrong 'UserName'$")
	public void user_clicks_Save_entering_wrong_UserName() throws Throwable {
		objhbpg.setPffuname("123");
		objhbpg.setPfbutton();
		Thread.sleep(1000);
	}

	@Then("^display 'Please enter validUsername'$")
	public void display_Please_enter_validUsername() throws Throwable {
		Assert.assertEquals(driver.switchTo().alert().getText(), "please enter valid Username");
	}

	@When("^user clicks save entering wrong 'Password'$")
	public void user_clicks_save_entering_wrong_Password() throws Throwable {
		objhbpg.setPffuname("Srinivas");
		objhbpg.setPfpswd("123");
		objhbpg.setPfbutton();
		Thread.sleep(1000);
	}

	@Then("^display 'Please enter validPassword'$")
	public void display_Please_enter_validPassword() throws Throwable {
		Assert.assertEquals(driver.switchTo().alert().getText(), "please enter valid Password");
	}

    @When("^user clicks save entering wrong 'confirm Password'$")
    public void user_clicks_save_entering_wrong_confirm_Password() throws Throwable {
    	objhbpg.setPffuname("Srinivas");
		objhbpg.setPfpswd("Srinivas123");
		objhbpg.setPfcnfpswd("nikkon123");
		objhbpg.setPfbutton();
    }

   @Then("^display 'Please enter above Password'$")
    public void display_Please_enter_above_Password() throws Throwable {
	   Assert.assertEquals(driver.switchTo().alert().getText(), "Please enter above password!");
    }


	@When("^user enters valid details$")
	public void user_enters_valid_details() throws Throwable {
		objhbpg.setPffuname("Srinivas");
		objhbpg.setPfpswd("Srinivas123");
		objhbpg.setPfcnfpswd("Srinivas123");
		objhbpg.setPfbutton();
		Thread.sleep(1000);
	}

	@Then("^display 'changePassword'$")
	public void display_changePassword() throws Throwable {
		Assert.assertEquals(driver.switchTo().alert().getText(), "successfully Changed");
		driver.switchTo().alert().accept();
		driver.get("file:///C:/Users/admin/Desktop/PasswordChange.html");
	}

	@After
	public void afterchange() {
		driver.close();

	}

}
