package PageBean;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.CacheLookup;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class PasswordChangeBean {
	WebDriver driver;
	
	@FindBy(name = "txtUN")
	@CacheLookup
	WebElement pffuname;
	
	@FindBy(id="btnPayment")
	@CacheLookup
	WebElement pfbutton;
	
	@FindBy(name = "txtPSWD")
	@CacheLookup
	WebElement pfpswd;
	
	@FindBy(name = "cnfPSWD")
	@CacheLookup
	WebElement pfcnfpswd;
	
	
	public PasswordChangeBean(WebDriver driver) {
		this.driver = driver;
		PageFactory.initElements(driver, this);
	}


	public WebElement getPffuname() {
		return pffuname;
	}


	public void setPffuname(String sfuname) {
		pffuname.sendKeys(sfuname);
	}


	public WebElement getPfbutton() {
		return pfbutton;
	}


	public void setPfbutton() {
		pfbutton.click();
	}


	public WebElement getPfpswd() {
		return pfpswd;
	}


	public void setPfpswd(String sfpswd) {
	     pfpswd.sendKeys(sfpswd);
	}
	
	public WebElement getPfcnfpswd() {
	 		return pfcnfpswd;
		}
	
	public void setPfcnfpswd(String sfcnfpswd) {
	     pfcnfpswd.sendKeys(sfcnfpswd);
	}	
}
