package signupuser;

import java.util.concurrent.TimeUnit;
import java.util.regex.Pattern;

import org.junit.Assert;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

import cucumber.api.PendingException;
import cucumber.api.java.After;
import cucumber.api.java.Before;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import pageBean.SignUpUserPageFactory;

public class StepDefSignUpUser {
	private WebDriver driver;
	private SignUpUserPageFactory objhbpg;

	@Before
	public void openBrowsser() {
		System.setProperty("webdriver.chrome.driver", "D:\\Module3\\WebD\\chromedriver.exe");
		driver = new ChromeDriver();
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		objhbpg = new SignUpUserPageFactory(driver);

	    driver.get("file:///D:/Module3/SignUpUser.html");
	}

	@Given("^User is on sign up page$")
	public void user_is_on_sign_up_page() throws Throwable {
	    driver.get("file:///D:/Module3/SignUpUser.html");
	}

	@Then("^check the title of the page$")
	public void check_the_title_of_the_page() throws Throwable {
		String title = driver.getTitle();
		Assert.assertEquals(title, "Sign up user");
	}

	@When("^user keeps name blank$")
	public void user_keeps_name_blank() throws Throwable {
	  objhbpg.setPfname("");
	  objhbpg.setPfbutton();
	}

	@Then("^display alert message Please enter  Name$")
	public void display_alert_message_Please_enter_Name() throws Throwable {
		Assert.assertEquals(driver.switchTo().alert().getText(), "Please enter  Full Name.");

	}

	@When("^user keeps email blank$")
	public void user_keeps_email_blank() throws Throwable {
		 objhbpg.setPfname("Aditya");
		 objhbpg.setPfemail("");
		  objhbpg.setPfbutton();
	}

	@Then("^display alert message Please enter email$")
	public void display_alert_message_Please_enter_email() throws Throwable {
		Assert.assertEquals(driver.switchTo().alert().getText(), "Please enter the Email.");

	}

	@When("^user keeps mobile no blank$")
	public void user_keeps_mobile_no_blank() throws Throwable {
		 objhbpg.setPfname("Aditya");
		 objhbpg.setPfemail("aditya@gmail.com");
		 objhbpg.setPfmobile("");
		  objhbpg.setPfbutton();
	}

	@Then("^display alert message Please enter mobile number$")
	public void display_alert_message_Please_enter_mobile_number() throws Throwable {
		Assert.assertEquals(driver.switchTo().alert().getText(), "Please enter the Mobile No.");

	}

	@When("^user keeps password blank$")
	public void user_keeps_password_blank() throws Throwable {
		 objhbpg.setPfname("Aditya");
		 objhbpg.setPfemail("aditya@gmail.com");
		 objhbpg.setPfmobile("9821270584");
		 objhbpg.setPfPassword("");
		  objhbpg.setPfbutton();
	}

	@Then("^display alert message Please enter password$")
	public void display_alert_message_Please_enter_password() throws Throwable {
		Assert.assertEquals(driver.switchTo().alert().getText(), "Please enter your password.");

	}

	@When("^user keeps name confirm password blank$")
	public void user_keeps_name_confirm_password_blank() throws Throwable {
		 objhbpg.setPfname("Aditya");
		 objhbpg.setPfemail("aditya@gmail.com");
		 objhbpg.setPfmobile("9821270584");
		 objhbpg.setPfPassword("aditya123");
		 objhbpg.setPfConfPassword("");
		  objhbpg.setPfbutton();
	}

	@Then("^display alert message Please enter confirm password$")
	public void display_alert_message_Please_enter_confirm_password() throws Throwable {
		Assert.assertEquals(driver.switchTo().alert().getText(), "Please retype password in confirm password.");

	}

	@When("^user keeps address blank$")
	public void user_keeps_address_blank() throws Throwable {
		 objhbpg.setPfname("Aditya");
		 objhbpg.setPfemail("aditya@gmail.com");
		 objhbpg.setPfmobile("9821270584");
		 objhbpg.setPfPassword("aditya123");
		 objhbpg.setPfConfPassword("aditya123");
		 objhbpg.setPfAddress("");
		  objhbpg.setPfbutton();
	}

	@Then("^display alert message Please enter address blank$")
	public void display_alert_message_Please_enter_address_blank() throws Throwable {
		Assert.assertEquals(driver.switchTo().alert().getText(), "Please enter address.");

	}

	@When("^user does not select gender$")
	public void user_does_not_select_gender() throws Throwable {
		 objhbpg.setPfname("Aditya");
		 objhbpg.setPfemail("aditya@gmail.com");
		 objhbpg.setPfmobile("9821270584");
		 objhbpg.setPfPassword("aditya123");
		 objhbpg.setPfConfPassword("aditya123");
		 objhbpg.setPfAddress("Mumbai");
		  objhbpg.setPfbutton();
	}

	@Then("^display alert message Please select gender$")
	public void display_alert_message_Please_select_gender() throws Throwable {
		Assert.assertEquals(driver.switchTo().alert().getText(), "Select gender");

	}

	@When("^user all valid data$")
	public void user_all_valid_data() throws Throwable {
		 objhbpg.setPfname("Aditya");
		 objhbpg.setPfemail("aditya@gmail.com");
		 objhbpg.setPfmobile("9821270584");
		 objhbpg.setPfPassword("aditya123");
		 objhbpg.setPfConfPassword("aditya123");
		 objhbpg.setPfAddress("Mumbai");
		 objhbpg.setPfgenderm();
		  objhbpg.setPfbutton();
	}

	@Then("^display alert message account created successfully$")
	public void display_alert_message_account_created_successfully() throws Throwable {
		Assert.assertEquals(driver.switchTo().alert().getText(), "Account has been created successfully.");

	}
	@When("^user enters invalid name$")
	public void user_enters_invalid_name() throws Throwable {
	    objhbpg.setPfname("ada");
	    objhbpg.setPfbutton();
	}

	@Then("^display alert message Please enter valid name$")
	public void display_alert_message_Please_enter_valid_name() throws Throwable {
	   Assert.assertEquals(false, Pattern.matches("[A-Z][a-z]{2,30}", objhbpg.getPfname()+""));
	   Assert.assertEquals(driver.switchTo().alert().getText(), "Name should start with capital letter and must contain alphabets only");
	}

	@When("^user enters invalid email$")
	public void user_enters_invalid_email() throws Throwable {
		objhbpg.setPfname("Aditya");
		 objhbpg.setPfemail("aada");
		  objhbpg.setPfbutton();
	}

	@Then("^display alert message Please enter valid email$")
	public void display_alert_message_Please_enter_valid_email() throws Throwable {
		   Assert.assertEquals(false, Pattern.matches("[a-z0-9._%+-]+@[a-z0-9.-]+\\.[a-z]{2,3}", objhbpg.getPfemail()+""));
		   Assert.assertEquals(driver.switchTo().alert().getText(), "Please enter valid Email Id.");
	}

	@When("^user enters invalid mobile no\\.$")
	public void user_enters_invalid_mobile_no() throws Throwable {
		objhbpg.setPfname("Aditya");
		 objhbpg.setPfemail("aada@gmail.com");
		 objhbpg.setPfmobile("1236");
		  objhbpg.setPfbutton();
	}

	@Then("^display alert message Please enter valid mobile number$")
	public void display_alert_message_Please_enter_valid_mobile_number() throws Throwable {
		Assert.assertEquals(false, Pattern.matches("[7-9]{1}[0-9]{9}", objhbpg.getPfmobile()+""));
		Assert.assertEquals(driver.switchTo().alert().getText(), "Please enter valid Mobile No.");
	}

	@When("^user enters invalid pasword$")
	public void user_enters_invalid_pasword() throws Throwable {
		objhbpg.setPfname("Aditya");
		 objhbpg.setPfemail("aada@gmail.com");
		 objhbpg.setPfmobile("9821270584");
		 objhbpg.setPfPassword("ada");
		  objhbpg.setPfbutton();
	}

	@Then("^display alert message Please enter valid password$")
	public void display_alert_message_Please_enter_valid_password() throws Throwable {
		Assert.assertEquals(false, Pattern.matches("[a-z0-9]{8,20}", objhbpg.getPfpassword()+""));
		Assert.assertEquals(driver.switchTo().alert().getText(), "Password should be atleast 8 characters long ");
	}

	@When("^user entered confirm password does not match$")
	public void user_entered_confirm_password_does_not_match() throws Throwable {
		objhbpg.setPfname("Aditya");
		 objhbpg.setPfemail("aada@gmail.com");
		 objhbpg.setPfmobile("9821270584");
		 objhbpg.setPfPassword("adityaaa");
		 objhbpg.setPfConfPassword("aditya");
		  objhbpg.setPfbutton();
	}

	@Then("^display alert message Password do not match$")
	public void display_alert_message_Password_do_not_match() throws Throwable {
		Assert.assertEquals(driver.switchTo().alert().getText(), "Passwords do not match. Try again");
	}


	
	@After
	public void closebrowser()
	{
		driver.close();
	}


}
