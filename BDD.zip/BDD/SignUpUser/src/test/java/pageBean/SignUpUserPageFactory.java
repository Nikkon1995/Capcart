package pageBean;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.CacheLookup;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class SignUpUserPageFactory {
	WebDriver driver;

	// step1 identify elements
	

	@FindBy(name = "Name")
	@CacheLookup
	WebElement pfname;

	@FindBy(name = "Email")
	@CacheLookup
	WebElement pfemail;

	@FindBy(name = "Phone")
	@CacheLookup
	WebElement pfmobile;

	@FindBy(name = "Password")
	@CacheLookup
	WebElement pfpassword;

	@FindBy(name = "ConfirmPassword")
	@CacheLookup
	WebElement pfconfpassword;

	@FindBy(name = "address")
	@CacheLookup
	WebElement pfaddress;
	
	@FindBy(id = "txtGenderM")
	@CacheLookup
	WebElement pfgenderm;
	
	@FindBy(id = "txtGenderF")
	@CacheLookup
	WebElement pfgenderf;
	
	@FindBy(id = "btnRegister")
	@CacheLookup
	WebElement pfbutton;
	
	//step2 setters
	public void setPfname(String sfname) {
		pfname.sendKeys(sfname);
	}

		public void setPfemail(String semail) {
			pfemail.sendKeys(semail);
		}
		
		public void setPfmobile(String smobile) {
			pfmobile.sendKeys(smobile);
		}
		
		public void setPfPassword(String spassword)
		{
			pfpassword.sendKeys(spassword);
		}
		
		public void setPfConfPassword(String spasswordconfirm)
		{
			pfconfpassword.sendKeys(spasswordconfirm);
		}

		public void setPfAddress(String saddress)
		{
			pfaddress.sendKeys(saddress);
		}

		
	public void setPfbutton() {
			pfbutton.click();
		}

		public void setPfgenderm() {
			pfgenderm.click();
		}

		public void setPfgenderf() {
			pfgenderf.click();
		}
		
		//Step 3 getters
		public WebElement getPfname() {
			return pfname;
		}

		public WebElement getPfemail() {
			return pfemail;
		}

		public WebElement getPfmobile() {
			return pfmobile;
		}

		public WebElement getPfpassword() {
			return pfpassword;
		}

		public WebElement getPfconfpassword() {
			return pfconfpassword;
		}

		public WebElement getPfaddress() {
			return pfaddress;
		}

		public WebElement getPfgenderm() {
			return pfgenderm;
		}

		public WebElement getPfgenderf() {
			return pfgenderf;
		}

		public WebElement getPfbutton() {
			return pfbutton;
		}
		
	// step 4 initialization
	public SignUpUserPageFactory(WebDriver driver) {
		this.driver = driver;
		PageFactory.initElements(driver, this);
	}

}


