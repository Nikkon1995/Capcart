package com.cg.merchant.exception;

public class MerchantException extends Exception{
	
	private static final long serialVersionUID = 1L;
	String msg;

	public MerchantException(String msg) {
		this.msg = msg;
	}

	public String getMessage() {
		return msg;
	}

}
