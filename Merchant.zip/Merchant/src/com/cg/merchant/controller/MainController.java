package com.cg.merchant.controller;

import java.util.ArrayList;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

import com.cg.merchant.model.Merchant;
import com.cg.merchant.model.Product;
import com.cg.merchant.service.IMerchantService;

@Controller
public class MainController {
	@Autowired
	IMerchantService service;

	@RequestMapping("/home")
	public String displayPage(Model model) {
		String view = "merchantLogin";
		return view;
	}

	@RequestMapping(value = "/createAccount")
	public String AccountCreated(Model model) {
		String view = "CreateAccount";
		model.addAttribute("Merchant", new Merchant());
		return view;
	}

	@RequestMapping(value = "/accountSuccess", method = RequestMethod.POST)
	public String AccountSuccess(Model model, @ModelAttribute("Merchant") Merchant merchant) {
		System.out.println(merchant);
		String view = "";
		
		int id = service.addMerchant(merchant);
		merchant.setRegId(id);

		if (merchant.getRegId() == 0) {
			view = "CreateAccount";
		} else {
			
			//model.addAttribute("accountId", id);
			view = "merchantLogin";
		}
		return view;
	}

	@RequestMapping(value = "/merchantProfile", method = RequestMethod.POST)
	public String SuccessLogin(Model model, @RequestParam("merchantUsername") String merchantUsername,
			@RequestParam("merchantPassword") String merchantPassword) {
		String view = "";
		boolean reply = service.loginAccount(merchantUsername, merchantPassword);
		model.addAttribute("merchantUsername", merchantUsername);
		if (reply == true) {
			view = "profilePage";

		} else {
			view = "merchantLogin";
		}

		return view;
	}
	
	@RequestMapping("/merchantProduct")
	public String displayProductPage(Model model) {
		String view = "";
		
		try {
			ArrayList<?> list= service.getAllProducts();
			if(list.isEmpty())
				model.addAttribute("productList",null);
			else
				model.addAttribute("productList",list);
			view="merchantProduct";
		}catch(Exception e) {
			model.addAttribute("error", e.getMessage());
			view="errorpage";
		}
		
		
		return view;
	}

	@RequestMapping("/forgot")
	public String displayForgotPage(Model model) {
		String view = "";
	
			view="forgotPassword";
		
		return view;
	}
	@RequestMapping(value = "/addProduct")
	public String productAdded(Model model) {
		String view = "addProduct";
		model.addAttribute("Product", new Product());
		return view;
	}
	
	@RequestMapping(value="/productSuccess")
	public String productSuccess(Model model, @ModelAttribute("Product") Product product) {
		System.out.println(product);
		String view = "";
		
		int id = service.addProduct(product);
		product.setProductId(id);

		if (product.getProductId() == 0) {
			view = "addProduct";
		} else {
			
			//model.addAttribute("accountId", id);
			view = "merchantProduct";
		}
		return view;
	}
	@RequestMapping(value="/updateProduct")
	public String updateProducts(Model model) {
		String view= "updateProduct";
		return view;
		
	}
	
	@RequestMapping(value="/updateSuccess")
	public String updateProducts(Model model,@RequestParam("productId") String productId, @RequestParam("productPrice") String productPrice,
			@RequestParam("couponId") String couponId,@RequestParam("discountId") String discountId ) {
		String view= "updateSuccess";
		
		model.addAttribute("productId", productId);
		return view;
		
	}
	

	
	/*// New Passward screen is shown
		public String newPassward(Model model, @RequestParam("uname") String uname) {
			String passward = service.forgotPassword(uname);
			model.addAttribute("pass", passward);
			return "newPassWord";
		}
*/
}
