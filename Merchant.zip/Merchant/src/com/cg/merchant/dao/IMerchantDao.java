package com.cg.merchant.dao;

import com.cg.merchant.exception.MerchantException;
import com.cg.merchant.model.Merchant;
import com.cg.merchant.model.Product;

public interface IMerchantDao {

	public int addMerchant(Merchant merchant) throws MerchantException;

	public String loginAccount(String merchantUsername);

	public int addProduct(Product product);
}
