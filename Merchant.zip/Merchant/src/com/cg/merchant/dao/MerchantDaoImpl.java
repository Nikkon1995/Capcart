package com.cg.merchant.dao;

import java.util.ArrayList;

import javax.persistence.EntityManager;

import javax.persistence.PersistenceContext;
import javax.persistence.Query;

import org.springframework.stereotype.Repository;

import com.cg.merchant.model.Merchant;
import com.cg.merchant.model.Product;

@Repository
public class MerchantDaoImpl implements IMerchantDao {

	@PersistenceContext
	EntityManager manager;

	@Override
	public int addMerchant(Merchant merchant) {

		manager.persist(merchant);

		// merchant.setMerchantUsername();

		int id = this.getMerchantId();
		merchant.setRegId(id);
		/*
		 * if (id == 0) throw new
		 * MerchantException("Merchant Account creation failed!");
		 */
		return id;
	}

	public int getMerchantId() {
		int id = 0;
		String jpql = "Select max(merchant.regId) from Merchant merchant";
		Query query = manager.createQuery(jpql);
		id = (int) query.getSingleResult();
		return id;
	}

	public String loginAccount(String merchantUsername) {
		// TODO Auto-generated method stub
		System.out.println("UserName===============================================" + merchantUsername);
		String pass = "";
		try {
			String jpql = "Select merchant.merchantPassword from Merchant merchant where merchant.merchantUsername=:uname";
			Query query = manager.createQuery(jpql);
			query.setParameter("uname", merchantUsername);
			pass = (String) query.getSingleResult();
			System.out.println("----------------#########   Password " + pass);
		} catch (Exception e) {
			e.getMessage();
		}
		return pass;
	}

	public int addProduct(Product product) {
		manager.persist(product);
		int productId = this.getProdId();
		product.setProductId(productId);
		return productId;
	}

	public int getProdId() {
		int id = 0;
		String jpql = "Select max(product.productId) from Product product";
		Query query = manager.createQuery(jpql);
		id = (int) query.getSingleResult();
		return id;
	}

	public ArrayList<?> getAllProducts() {
		
		String jpql="Select obj from Product obj";
		Query query=manager.createQuery(jpql);
		ArrayList<?>list=(ArrayList<?>)query.getResultList();
		return list;
	}
}

/// INSERT code for forgot password
