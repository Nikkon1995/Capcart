package com.cg.merchant.service;

import java.util.ArrayList;

import com.cg.merchant.model.Merchant;
import com.cg.merchant.model.Product;

public interface IMerchantService {


	public int addMerchant(Merchant merchant);

	public boolean loginAccount(String merchantUsername, String merchantPassword);

	//public boolean resetPassword(String merchantUsername, String merchantPassword);
	
	public int addProduct(Product product);

	public ArrayList<?> getAllProducts();
	

}
