package com.cg.merchant.service;

import java.util.ArrayList;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.cg.merchant.dao.MerchantDaoImpl;
import com.cg.merchant.model.Merchant;
import com.cg.merchant.model.Product;


@Service
@Transactional
public class MerchantServiceImpl implements IMerchantService {
	@Autowired
	MerchantDaoImpl dao;
	
	@Override
	public int addMerchant(Merchant merchant) {
		
		return dao.addMerchant(merchant);
	}

	@Override
	public boolean loginAccount(String merchantUsername, String merchantPassword) {
		
		String pwd=dao.loginAccount( merchantUsername);
		if(pwd.equals( merchantPassword))
		{
		return true;	
		}
		else
			return false;
	}
/*
	@Override
	public boolean resetPassword(String merchantUsername, String merchantPassword) {
		
		String pwd=dao.resetPassword(merchantUsername,merchantPassword);
		return false;
		
	}*/

	@Override
	public int addProduct(Product product) {
		// TODO Auto-generated method stub
		return dao.addProduct(product);
	}

	@Override
	public ArrayList<?> getAllProducts() {
		// TODO Auto-generated method stub
		return dao.getAllProducts();
	}

}
